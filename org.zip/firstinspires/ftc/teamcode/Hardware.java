 /* Copyright (c) 2017 FIRST. All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted (subject to the limitations in the disclaimer below) provided that
  * the following conditions are met:
  *
  * Redistributions of source code must retain the above copyright notice, this list
  * of conditions and the following disclaimer.
  *
  * Redistributions in binary form must reproduce the above copyright notice, this
  * list of conditions and the following disclaimer in the documentation and/or
  * other materials provided with the distribution.
  *
  * Neither the name of FIRST nor the names of its contributors may be used to endorse or
  * promote products derived from this software without specific prior written permission.
  *
  * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
  * LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
  * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  */
 
 package org.firstinspires.ftc.teamcode;
 
 import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
 import com.qualcomm.robotcore.hardware.Servo;
 import com.qualcomm.robotcore.eventloop.opmode.Disabled;
 import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
 import com.qualcomm.robotcore.hardware.DcMotor;
 import com.qualcomm.robotcore.hardware.HardwareMap;
 import com.qualcomm.robotcore.util.ElapsedTime;
 import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
 import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
 
 /*
  * This OpMode illustrates the concept of driving a path based on encoder counts.
  * The code is structured as a LinearOpMode
  *
  * The code REQUIRES that you DO have encoders on the wheels,
  *   otherwise you would use: RobotAutoDriveByTime;
  *
  *  This code ALSO requires that the drive Motors have been configured such that a positive
  *  power command moves them forward, and causes the encoders to count UP.
  *
  *   The desired path in this example is:
  *   - Drive forward for 48 inches
  *   - Spin right for 12 Inches
  *   - Drive Backward for 24 inches
  *   - Stop and close the claw.
  *
  *  The code is written using a method called: encoderDrive(speed, leftInches, rightInches, timeoutS)
  *  that performs the actual movement.
  *  This method assumes that each movement is relative to the last stopping place.
  *  There are other ways to perform encoder based moves, but this method is probably the simplest.
  *  This code uses the RUN_TO_POSITION mode to enable the Motor controllers to generate the run profile
  *
  * Use Android Studio to Copy this Class, and Paste it into your team's code folder with a new name.
  * Remove or comment out the @Disabled line to add this OpMode to the Driver Station OpMode list
  */
 
 public class Hardware {
 
     /* Declare OpMode members. */
     public DcMotor         frontLeft   = null;
     public DcMotor         backRight  = null;
     public DcMotor         backLeft   = null;
     public DcMotor         frontRight  = null;
     public DcMotor outtakeL = null;
     public DcMotor outtakeR = null;
     public DcMotor intake = null;
     public DcMotor elevator = null;
     public Servo scoop = null;
     
     HardwareMap hwMap           =  null;
     public ElapsedTime period  = new ElapsedTime();


     public void init(HardwareMap ahwMap) {
         //Save reference to Hardware map
         hwMap = ahwMap;
         //left front drive motor
         try {
 
         frontLeft = hwMap.dcMotor.get("frontLeft");
         } catch (Exception p_exeception) {
 
             frontLeft = null;
         }

         //left back drive motor
         try {
 
             backLeft = hwMap.dcMotor.get("backLeft");
         } catch (Exception p_exeception) {
 
             backLeft = null;
         }
          //right front drive motor
         try {
 
             frontRight = hwMap.dcMotor.get("frontRight");
         } catch (Exception p_exeception) {
 
             frontRight = null;
         }
         //right back drive motor
         try {
 
             backRight = hwMap.dcMotor.get("backRight");
         } catch (Exception p_exeception) {
 
             backRight = null;
         }
         
         try {
 
             outtakeL = hwMap.dcMotor.get("outtake_L");
         } catch (Exception p_exeception) {
 
             outtakeL = null;
         }
         try {
 
             outtakeR = hwMap.dcMotor.get("outtake_R");
         } catch (Exception p_exeception) {
 
             outtakeR = null;
         }
         
         try {
 
             intake = hwMap.dcMotor.get("intake");
         } catch (Exception p_exeception) {
 
             intake = null;
         }
         
         try {
 
             elevator = hwMap.dcMotor.get("elevator");
         } catch (Exception p_exeception) {
 
             elevator = null;
         }
         
         if (frontLeft != null) {
            frontLeft.setDirection(DcMotor.Direction.REVERSE); // FORWARD was moving it backwards
            frontLeft.setPower(0);
            frontLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        //l_b_drv
        if (backLeft != null) {
            backLeft.setDirection(DcMotor.Direction.REVERSE); // FORWARD was moving it backwards
            backLeft.setPower(0);
            backLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }

        //r_f_drv
        if (frontRight != null) {
            frontRight.setDirection(DcMotor.Direction.FORWARD);// REVERSE was moving it backwards
            frontRight.setPower(0);
            frontRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        //r_b_drv
        if (backRight != null) {
            backRight.setDirection(DcMotor.Direction.FORWARD);// REVERSE was moving it backwards
            backRight.setPower(0);
            backRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        
        if (outtakeR != null) {
            outtakeR.setDirection(DcMotor.Direction.FORWARD);// REVERSE was moving it backwards
            outtakeR.setPower(0);
            outtakeR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        
        if (outtakeL != null) {
            outtakeL.setDirection(DcMotor.Direction.FORWARD);// REVERSE was moving it backwards
            outtakeL.setPower(0);
            outtakeL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        
        if (intake != null) {
            intake.setDirection(DcMotor.Direction.FORWARD);// REVERSE was moving it backwards
            intake.setPower(0);
            intake.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        
        if (elevator != null) {
            elevator.setDirection(DcMotor.Direction.REVERSE);// REVERSE was moving it backwards
            elevator.setPower(0);
            elevator.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        
        try {
            scoop = hwMap.servo.get("scoop");
        } catch (Exception p_exeception) {
            scoop = null;
        }
        
        if (scoop != null) {
            scoop.setPosition(0);
        }
     }
 }
 