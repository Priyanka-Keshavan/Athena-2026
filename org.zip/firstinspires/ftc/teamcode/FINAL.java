/* Copyright (c) 2017 FIRST. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided that
 * the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list
 * of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this
 * list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 *
 * Neither the name of FIRST nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
 * LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;


/*
 * This file contains an minimal example of a Linear "OpMode". An OpMode is a 'program' that runs in either
 * the autonomous or the teleop period of an FTC match. The names of OpModes appear on the menu
 * of the FTC Driver Station. When a selection is made from the menu, the corresponding OpMode
 * class is instantiated on the Robot Controller and executed.
 *
 * This particular OpMode just executes a basic Tank Drive Teleop for a two wheeled robot
 * It includes all the skeletal structure that all linear OpModes contain.
 *
 * Use Android Studio to Copy this Class, and Paste it into your team's code folder with a new name.
 * Remove or comment out the @Disabled line to add this OpMode to the Driver Station OpMode list
 */

@TeleOp(name="FINAL", group="Linear OpMode")

public class FINAL extends LinearOpMode {

    // Declare OpMode members.
    private ElapsedTime runtime = new ElapsedTime();
    private Hardware robot = new Hardware();
    private double MAX = 0.7;

    @Override
    public void runOpMode() {
        robot.init(hardwareMap);
        
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        
        waitForStart();
        runtime.reset();

        // run until the end of the match (driver presses STOP)
        while (opModeIsActive()) {

            // Setup a variable for each drive wheel to save power level for telemetry
            double leftFrontPower;
            double rightFrontPower;
            double leftBackPower;
            double rightBackPower;

            // Choose to drive using either Tank Mode, or POV Mode
            // Comment out the method that's not used.  The default below is POV.

            // POV Mode uses left stick to go forward, and right stick to turn.
            // - This uses basic math to combine motions and is easier to drive straight.
            double drive = -gamepad1.left_stick_y;
            double turn =  gamepad1.left_stick_x;
            if (gamepad1.right_bumper)
                turn = gamepad1.left_stick_x;
            else if (turn > 0)
                turn = MAX / 2;
            else if (turn < 0)
                turn = -MAX / 2;
            double strafe = gamepad1.right_stick_x;
            if (strafe == 0) {
                leftFrontPower    = Range.clip(drive + turn, -MAX, MAX) ;
                rightFrontPower   = Range.clip(drive - turn, -MAX, MAX) ;
                leftBackPower    = Range.clip(drive + turn, -MAX, MAX) ;
                rightBackPower   = Range.clip(drive - turn, -MAX, MAX) ;
            } else {
                leftFrontPower    = Range.clip(strafe, -MAX - 0.2, MAX + 0.2) ;
                rightFrontPower   = Range.clip(-strafe, -MAX - 0.2, MAX + 0.2) ;
                leftBackPower    = Range.clip(-strafe, -MAX - 0.2, MAX + 0.2) ;
                rightBackPower   = Range.clip(strafe, -MAX - 0.2, MAX + 0.2) ;
            }

            // Tank Mode uses one stick to control each wheel.
            // - This requires no math, but it is hard to drive forward slowly and keep straight.
            // leftPower  = -gamepad1.left_stick_y ;
            // rightPower = -gamepad1.right_stick_y ;

            // Send calculated power to wheels
            robot.frontLeft.setPower(leftFrontPower);
            robot.frontRight.setPower(rightFrontPower);
            robot.backLeft.setPower(leftBackPower);
            robot.backRight.setPower(rightBackPower);
            
            if (gamepad1.rightBumperWasPressed()) {
                MAX = 0.8;
            }
            if (gamepad1.leftBumperWasPressed()) {
                MAX = 0.38;
            }
            if (gamepad1.right_trigger > 0) {
                MAX = 0.53;
            }
            if (gamepad1.left_trigger > 0) {
                MAX = 0.45;
            }
            if (gamepad1.x) {
                MAX = 1.0;
            }
            
            
            if (gamepad2.right_stick_y != 0) {
                robot.outtakeR.setPower(-gamepad2.right_stick_y);
                robot.outtakeL.setPower(-gamepad2.right_stick_y);
            } else if (gamepad2.right_trigger > 0) {
                robot.outtakeR.setPower(1.0);
                robot.outtakeL.setPower(1.0);
            } else {
                robot.outtakeR.setPower(0);
                robot.outtakeL.setPower(0);
            }
            
            //input
            double intakePower;
            double elevatorPower = 1.0; 
            if (gamepad2.left_stick_y != 0) {
                intakePower = Range.clip(-gamepad2.left_stick_y, -0.55, 0.9);
                elevatorPower = Range.clip(-gamepad2.left_stick_y, -1.0, 1.0);
                robot.intake.setPower(intakePower);
                robot.elevator.setPower(elevatorPower);
            }
            
            
            if (gamepad2.left_trigger != 0) {
                intakePower  = Range.clip(-gamepad2.left_trigger, -0.5, 0) ;
                robot.intake.setPower(-intakePower);
                robot.elevator.setPower(elevatorPower);
            }
            robot.elevator.setPower(0);
            robot.intake.setPower(0);
            
            if (gamepad2.left_bumper || gamepad2.right_bumper) {
                robot.scoop.setPosition(0.6);
            } else {
                robot.scoop.setPosition(0);
            }
            
            // Show the elapsed game time and wheel power.
            telemetry.addData("Status", "Run Time: " + runtime.toString());
            telemetry.addData("MAX SPEED", MAX);
            //telemetry.addData("Motors", "left (%.2f), right (%.2f)", rightPower);
            telemetry.update();
        }
    }
}
