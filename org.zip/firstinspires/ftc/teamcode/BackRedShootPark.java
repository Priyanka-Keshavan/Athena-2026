// /* Copyright (c) 2017 FIRST. All rights reserved.
//  *
//  * Redistribution and use in source and binary forms, with or without modification,
//  * are permitted (subject to the limitations in the disclaimer below) provided that
//  * the following conditions are met:
//  *
//  * Redistributions of source code must retain the above copyright notice, this list
//  * of conditions and the following disclaimer.
//  *
//  * Redistributions in binary form must reproduce the above copyright notice, this
//  * list of conditions and the following disclaimer in the documentation and/or
//  * other materials provided with the distribution.
//  *
//  * Neither the name of FIRST nor the names of its contributors may be used to endorse or
//  * promote products derived from this software without specific prior written permission.
//  *
//  * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
//  * LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//  * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
//  * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
//  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
//  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
//  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//  */
// 
// package org.firstinspires.ftc.teamcode;
// 
// import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
// import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
// import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
// import com.qualcomm.robotcore.util.ElapsedTime;
// import com.qualcomm.robotcore.hardware.DcMotor;
// import com.qualcomm.robotcore.eventloop.opmode.Disabled;
// import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
// import com.qualcomm.robotcore.hardware.DcMotor;
// import com.qualcomm.robotcore.hardware.HardwareMap;
// import com.qualcomm.robotcore.util.ElapsedTime;
// 
// /*
//  * This OpMode illustrates the concept of driving a path based on encoder counts.
//  * The code is structured as a LinearOpMode
//  *
//  * The code REQUIRES that you DO have encoders on the wheels,
//  *   otherwise you would use: RobotAutoDriveByTime;
//  *
//  *  This code ALSO requires that the drive Motors have been configured such that a positive
//  *  power command moves them forward, and causes the encoders to count UP.
//  *
//  *   The desired path in this example is:
//  *   - Drive forward for 48 inches
//  *   - Spin right for 12 Inches
//  *   - Drive Backward for 24 inches
//  *   - Stop and close the claw.
//  *
//  *  The code is written using a method called: encoderDrive(speed, leftInches, rightInches, timeoutS)
//  *  that performs the actual movement.
//  *  This method assumes that each movement is relative to the last stopping place.
//  *  There are other ways to perform encoder based moves, but this method is probably the simplest.
//  *  This code uses the RUN_TO_POSITION mode to enable the Motor controllers to generate the run profile
//  *
//  * Use Android Studio to Copy this Class, and Paste it into your team's code folder with a new name.
//  * Remove or comment out the @Disabled line to add this OpMode to the Driver Station OpMode list
//  */
// 
// @Autonomous(name = "BackRedShootPark", group = "Concept")
// public class BackRedShootPark extends LinearOpMode {
// 
//     /* Declare OpMode members. */
//     private Hardware robot = new Hardware();
//     private ElapsedTime     runtime = new ElapsedTime();
// 
//     // Calculate the COUNTS_PER_INCH for your specific drive train.
//     // Go to your motor vendor website to determine your motor's COUNTS_PER_MOTOR_REV
//     // For external drive gearing, set DRIVE_GEAR_REDUCTION as needed.
//     // For example, use a value of 2.0 for a 12-tooth spur gear driving a 24-tooth spur gear.
//     // This is gearing DOWN for less speed and more torque.
//     // For gearing UP, use a gear ratio less than 1.0. Note this will affect the direction of wheel rotation.
//     static final double     COUNTS_PER_MOTOR_REV    = 384.6 ;    // eg: TETRIX Motor Encoder
//     static final double     DRIVE_GEAR_REDUCTION    = 0.667 ;     // No External Gearing.
//     static final double     WHEEL_DIAMETER_INCHES   = 4.0 ;     // For figuring circumference
//     static final double     COUNTS_PER_INCH         = (COUNTS_PER_MOTOR_REV * DRIVE_GEAR_REDUCTION) /
//                                                       (WHEEL_DIAMETER_INCHES * 3.1415);
//     static final double     DRIVE_SPEED             = 0.25;
//     static final double     TURN_SPEED              = 0.2;
// 
//     @Override
//     public void runOpMode() {
// 
//         /*
//          * Initialize the drive system variables.
//          * The init() method of the hardware class does all the work here
//          */
//         robot.init(hardwareMap);
// 
//         
//         robot.frontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//         robot.frontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//         robot.backLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//         robot.backRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
// 
// 
//         robot.frontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//         robot.frontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//         robot.backLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//         robot.backRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//         //robot.hang_motor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
// 
//         // Send telemetry message to indicate successful Encoder reset
//         telemetry.addData("Path0", "Starting at %7d :%7d :%7d :%7d",
//                 robot.frontLeft.getCurrentPosition(),
//                 robot.frontRight.getCurrentPosition(),
//                 robot.backLeft.getCurrentPosition(),
//                 robot.backRight.getCurrentPosition()
//         );
//         telemetry.update();
// 
//         // Wait for the game to start (driver presses PLAY)
//         waitForStart();
// 
//         // Step through each leg of the path,
//         // Note: Reverse movement is obtained by setting a negative distance (not speed)
//         //come down
//         // Step 3:  Drive Backwards for 1 Second
//         //robot.hang_motor.setPower(-.5);
//         runtime.reset();
//         runtime.reset();
//         while (opModeIsActive() && runtime.seconds() < 10 && (runtime.seconds() < 1.0)) {
//             telemetry.addData("Path", "Leg 3: %2.5f S Elapsed", runtime.seconds());
//             telemetry.update();
//         }
// 
//         //WHERE ACTUAL CODE GOES
//         drive(-72);
//         turn(60);
//         shoot();
//         turn(-88);
//         strafe(53);
//         intake(true);
//         drive(50);
//         intake(false);
//         drive(-96);
//         strafe(12);
//         /*
//         
//         
//         intake(false);
//         elevator.setPower(0);
//         drive(-48);
//         turn(-90);
//         drive(-48);
//         turn(-47);
//         shoot();
//         */
// 
//         telemetry.addData("Path", "Complete");
//         telemetry.update();
//     }
// 
//     public void drive(double Inches) {
//         int newFrontLeftTarget;
//         int newFrontRightTarget;
//         int newBackLeftTarget;
//         int newBackRightTarget;
// 
//         // Ensure that the opmode is still active
//         if (opModeIsActive()) {
// 
//             // Determine new target position, and pass to motor controller
//             newFrontLeftTarget =  robot.frontLeft.getCurrentPosition() + (int) (Inches * COUNTS_PER_INCH);
//             newFrontRightTarget =  robot.frontRight.getCurrentPosition() + (int) (Inches * COUNTS_PER_INCH);
//             newBackLeftTarget = robot.backLeft.getCurrentPosition() + (int) (Inches * COUNTS_PER_INCH);
//             newBackRightTarget = robot.backRight.getCurrentPosition() + (int) (Inches * COUNTS_PER_INCH);
//             robot.frontLeft.setTargetPosition(newFrontLeftTarget);
//             robot.frontRight.setTargetPosition(newFrontRightTarget);
//             robot.backLeft.setTargetPosition(newBackLeftTarget);
//             robot.backRight.setTargetPosition(newBackRightTarget);
// 
//             // Turn On RUN_TO_POSITION
//             robot.frontLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.frontRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.backLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.backRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
// 
//             // reset the timeout time and start motion.
//             runtime.reset();
//             //accelerate(DRIVE_SPEED,newBackLeftTarget);
// 
//             robot.frontLeft.setPower(Math.abs(DRIVE_SPEED));
//             robot.frontRight.setPower(Math.abs(DRIVE_SPEED));
//             robot.backLeft.setPower(Math.abs(DRIVE_SPEED));
//             robot.backRight.setPower(Math.abs(DRIVE_SPEED));
// 
//             // keep looping while we are still active, and there is time left, and both motors are running.
//             // Note: We use (isBusy() && isBusy()) in the loop test, which means that when EITHER motor hits
//             // its target position, the motion will stop.  This is "safer" in the event that the robot will
//             // always end the motion as soon as possible.
//             // However, if you require that BOTH motors have finished their moves before the robot continues
//             // onto the next step, use (isBusy() || isBusy()) in the loop test.
//             runtime.reset();
//             while (opModeIsActive() && runtime.seconds() < 30 &&
//                         robot.frontLeft.isBusy() &&   robot.frontRight.isBusy() && robot.backRight.isBusy() && robot.backLeft.isBusy()) {
// 
//                 // Display it for the driver.
//                 telemetry.addData("Path1", "Running to %7d :%7d :%7d :%7d", newFrontLeftTarget, newFrontRightTarget, newBackLeftTarget, newBackRightTarget);
//                 telemetry.addData("Path2", "Running at %7d :%7d",
//                         robot.frontLeft.getCurrentPosition(),
//                         robot.frontRight.getCurrentPosition());
//                 telemetry.update();
//             }
// 
// 
//             // Stop all motion;
//             robot.frontLeft.setPower(0);
//             robot.frontRight.setPower(0);
//             robot.backLeft.setPower(0);
//             robot.backRight.setPower(0);
// 
//             // Turn off RUN_TO_POSITION
//             robot.frontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.frontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.backLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.backRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
// 
//             //sleep(250);   // optional pause after each move
//         }
//     }
//     
// 
//     public void drive(double speed, double Inches) {
//         int newFrontLeftTarget;
//         int newFrontRightTarget;
//         int newBackLeftTarget;
//         int newBackRightTarget;
// 
//         // Ensure that the opmode is still active
//         if (opModeIsActive()) {
// 
//             // Determine new target position, and pass to motor controller
//             newFrontLeftTarget =  robot.frontLeft.getCurrentPosition() + (int) (Inches * COUNTS_PER_INCH);
//             newFrontRightTarget =  robot.frontRight.getCurrentPosition() + (int) (Inches * COUNTS_PER_INCH);
//             newBackLeftTarget = robot.backLeft.getCurrentPosition() + (int) (Inches * COUNTS_PER_INCH);
//             newBackRightTarget = robot.backRight.getCurrentPosition() + (int) (Inches * COUNTS_PER_INCH);
//             robot.frontLeft.setTargetPosition(newFrontLeftTarget);
//             robot.frontRight.setTargetPosition(newFrontRightTarget);
//             robot.backLeft.setTargetPosition(newBackLeftTarget);
//             robot.backRight.setTargetPosition(newBackRightTarget);
// 
//             // Turn On RUN_TO_POSITION
//             robot.frontLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.frontRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.backLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.backRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
// 
//             // reset the timeout time and start motion.
//             runtime.reset();
//             //accelerate(DRIVE_SPEED,newBackLeftTarget);
// 
//             robot.frontLeft.setPower(Math.abs(speed));
//             robot.frontRight.setPower(Math.abs(speed));
//             robot.backLeft.setPower(Math.abs(speed));
//             robot.backRight.setPower(Math.abs(speed));
// 
//             // keep looping while we are still active, and there is time left, and both motors are running.
//             // Note: We use (isBusy() && isBusy()) in the loop test, which means that when EITHER motor hits
//             // its target position, the motion will stop.  This is "safer" in the event that the robot will
//             // always end the motion as soon as possible.
//             // However, if you require that BOTH motors have finished their moves before the robot continues
//             // onto the next step, use (isBusy() || isBusy()) in the loop test.
//             runtime.reset();
//             while (opModeIsActive() && runtime.seconds() < 10 &&
//                 
//                         robot.frontLeft.isBusy() &&   robot.frontRight.isBusy() && robot.backRight.isBusy() && robot.backLeft.isBusy()) {
// 
//                 // Display it for the driver.
//                 telemetry.addData("Path1", "Running to %7d :%7d :%7d :%7d", newFrontLeftTarget, newFrontRightTarget, newBackLeftTarget, newBackRightTarget);
//                 telemetry.addData("Path2", "Running at %7d :%7d",
//                         robot.frontLeft.getCurrentPosition(),
//                         robot.frontRight.getCurrentPosition());
//                 telemetry.update();
//             }
// 
// 
//             // Stop all motion;
//             robot.frontLeft.setPower(0);
//             robot.frontRight.setPower(0);
//             robot.backLeft.setPower(0);
//             robot.backRight.setPower(0);
// 
//             // Turn off RUN_TO_POSITION
//             robot.frontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.frontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.backLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.backRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
// 
//             sleep(250);   // optional pause after each move
//         }
//     }
// 
//     public void strafe(double inches) {
//         int newFrontLeftTarget;
//         int newFrontRightTarget;
//         int newBackLeftTarget;
//         int newBackRightTarget;
// 
//         // Ensure that the opmode is still active
//         if (opModeIsActive()) {
// 
//             // Determine new target position, and pass to motor controller
//             newFrontLeftTarget =  robot.frontLeft.getCurrentPosition() + (int) (inches * COUNTS_PER_INCH);
//             newFrontRightTarget =  robot.frontRight.getCurrentPosition() + (int) (-inches * COUNTS_PER_INCH);
//             newBackLeftTarget = robot.backLeft.getCurrentPosition() + (int) (-inches * COUNTS_PER_INCH);
//             newBackRightTarget = robot.backRight.getCurrentPosition() + (int) (inches * COUNTS_PER_INCH);
//             robot.frontLeft.setTargetPosition(newFrontLeftTarget);
//             robot.frontRight.setTargetPosition(newFrontRightTarget);
//             robot.backLeft.setTargetPosition(newBackLeftTarget);
//             robot.backRight.setTargetPosition(newBackRightTarget);
// 
//             // Turn On RUN_TO_POSITION
//             robot.frontLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.frontRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.backLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.backRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
// 
//             // reset the timeout time and start motion.
//             runtime.reset();
//             //accelerate(DRIVE_SPEED,newBackLeftTarget);
//             robot.frontLeft.setPower(Math.abs(DRIVE_SPEED));
//             robot.frontRight.setPower(Math.abs(DRIVE_SPEED));
//             robot.backLeft.setPower(Math.abs(DRIVE_SPEED));
//             robot.backRight.setPower(Math.abs(DRIVE_SPEED));
//             // keep looping while we are still active, and there is time left, and both motors are running.
//             // Note: We use (isBusy() && isBusy()) in the loop test, which means that when EITHER motor hits
//             // its target position, the motion will stop.  This is "safer" in the event that the robot will
//             // always end the motion as soon as possible.
//             // However, if you require that BOTH motors have finished their moves before the robot continues
//             // onto the next step, use (isBusy() || isBusy()) in the loop test.
//             runtime.reset();
//             while (opModeIsActive() && runtime.seconds() < 10 &&
//                     
//                         robot.frontLeft.isBusy() &&   robot.frontRight.isBusy() && robot.backRight.isBusy() && robot.backLeft.isBusy()) {
// 
//                 // Display it for the driver.
//                 telemetry.addData("Path1", "Running to %7d :%7d :%7d :%7d", newFrontLeftTarget, newFrontRightTarget, newBackLeftTarget, newBackRightTarget);
//                 telemetry.addData("Path2", "Running at %7d :%7d",
//                         robot.frontLeft.getCurrentPosition(),
//                         robot.frontRight.getCurrentPosition());
//                 telemetry.update();
//             }
// 
// 
//             // Stop all motion;
//             robot.frontLeft.setPower(0);
//             robot.frontRight.setPower(0);
//             robot.backLeft.setPower(0);
//             robot.backRight.setPower(0);
// 
//             // Turn off RUN_TO_POSITION
//             robot.frontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.frontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.backLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.backRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
// 
//             //  sleep(250);   // optional pause after each move
//         }
//     }
// 
// public void strafe(double speed, double inches) {
//         int newFrontLeftTarget;
//         int newFrontRightTarget;
//         int newBackLeftTarget;
//         int newBackRightTarget;
// 
//         // Ensure that the opmode is still active
//         if (opModeIsActive()) {
// 
//             // Determine new target position, and pass to motor controller
//             newFrontLeftTarget =  robot.frontLeft.getCurrentPosition() + (int) (inches * COUNTS_PER_INCH);
//             newFrontRightTarget =  robot.frontRight.getCurrentPosition() + (int) (-inches * COUNTS_PER_INCH);
//             newBackLeftTarget = robot.backLeft.getCurrentPosition() + (int) (-inches * COUNTS_PER_INCH);
//             newBackRightTarget = robot.backRight.getCurrentPosition() + (int) (inches * COUNTS_PER_INCH);
//             robot.frontLeft.setTargetPosition(newFrontLeftTarget);
//             robot.frontRight.setTargetPosition(newFrontRightTarget);
//             robot.backLeft.setTargetPosition(newBackLeftTarget);
//             robot.backRight.setTargetPosition(newBackRightTarget);
// 
//             // Turn On RUN_TO_POSITION
//             robot.frontLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.frontRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.backLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.backRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
// 
//             // reset the timeout time and start motion.
//             runtime.reset();
//             //accelerate(DRIVE_SPEED,newBackLeftTarget);
//             robot.frontLeft.setPower(Math.abs(speed));
//             robot.frontRight.setPower(Math.abs(speed));
//             robot.backLeft.setPower(Math.abs(speed));
//             robot.backRight.setPower(Math.abs(speed));
//             // keep looping while we are still active, and there is time left, and both motors are running.
//             // Note: We use (isBusy() && isBusy()) in the loop test, which means that when EITHER motor hits
//             // its target position, the motion will stop.  This is "safer" in the event that the robot will
//             // always end the motion as soon as possible.
//             // However, if you require that BOTH motors have finished their moves before the robot continues
//             // onto the next step, use (isBusy() || isBusy()) in the loop test.
//             runtime.reset();
//             while (opModeIsActive() && runtime.seconds() < 10 &&
//                     
//                         robot.frontLeft.isBusy() &&   robot.frontRight.isBusy() && robot.backRight.isBusy() && robot.backLeft.isBusy()) {
// 
//                 // Display it for the driver.
//                 telemetry.addData("Path1", "Running to %7d :%7d :%7d :%7d", newFrontLeftTarget, newFrontRightTarget, newBackLeftTarget, newBackRightTarget);
//                 telemetry.addData("Path2", "Running at %7d :%7d",
//                         robot.frontLeft.getCurrentPosition(),
//                         robot.frontRight.getCurrentPosition());
//                 telemetry.update();
//             }
// 
// 
//             // Stop all motion;
//             robot.frontLeft.setPower(0);
//             robot.frontRight.setPower(0);
//             robot.backLeft.setPower(0);
//             robot.backRight.setPower(0);
// 
//             // Turn off RUN_TO_POSITION
//             robot.frontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.frontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.backLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.backRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
// 
//             //  sleep(250);   // optional pause after each move
//         }
//     }
// 
//     public void turn(double degrees) {
//         int newFrontLeftTarget;
//         int newFrontRightTarget;
//         int newBackLeftTarget;
//         int newBackRightTarget;
//         degrees = degrees / 4 - 4;
// 
//         // Ensure that the opmode is still active
//         if (opModeIsActive()) {
// 
//             // Determine new target position, and pass to motor controller
//             newFrontLeftTarget =  robot.frontLeft.getCurrentPosition() + (int) (degrees * COUNTS_PER_INCH);
//             newFrontRightTarget =  robot.frontRight.getCurrentPosition() + (int) (-degrees * COUNTS_PER_INCH);
//             newBackLeftTarget = robot.backLeft.getCurrentPosition() + (int) (degrees * COUNTS_PER_INCH);
//             newBackRightTarget = robot.backRight.getCurrentPosition() + (int) (-degrees * COUNTS_PER_INCH);
//             robot.frontLeft.setTargetPosition(newFrontLeftTarget);
//             robot.frontRight.setTargetPosition(newFrontRightTarget);
//             robot.backLeft.setTargetPosition(newBackLeftTarget);
//             robot.backRight.setTargetPosition(newBackRightTarget);
// 
//             // Turn On RUN_TO_POSITION
//             robot.frontLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.frontRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.backLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//             robot.backRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
// 
//             // reset the timeout time and start motion.
//             runtime.reset();
//             robot.frontLeft.setPower(Math.abs(TURN_SPEED));
//             robot.frontRight.setPower(Math.abs(TURN_SPEED));
//             robot.backLeft.setPower(Math.abs(TURN_SPEED));
//             robot.backRight.setPower(Math.abs(TURN_SPEED));
// 
//             // keep looping while we are still active, and there is time left, and both motors are running.
//             // Note: We use (isBusy() && isBusy()) in the loop test, which means that when EITHER motor hits
//             // its target position, the motion will stop.  This is "safer" in the event that the robot will
//             // always end the motion as soon as possible.
//             // However, if you require that BOTH motors have finished their moves before the robot continues
//             // onto the next step, use (isBusy() || isBusy()) in the loop test.
//  
//             runtime.reset();
//             while (opModeIsActive() && runtime.seconds() < 10 && 
//                     
//                         robot.frontLeft.isBusy() &&   robot.frontRight.isBusy() && robot.backRight.isBusy() && robot.backLeft.isBusy()) {
// 
//                 // Display it for the driver.
//                 telemetry.addData("Path1", "Running to %7d :%7d :%7d :%7d", newFrontLeftTarget, newFrontRightTarget, newBackLeftTarget, newBackRightTarget);
//                 telemetry.addData("Path2", "Running at %7d :%7d",
//                         robot.frontLeft.getCurrentPosition(),
//                         robot.frontRight.getCurrentPosition());
//                 telemetry.update();
//             }
// 
// 
//             // Stop all motion;
//             robot.frontLeft.setPower(0);
//             robot.frontRight.setPower(0);
//             robot.backLeft.setPower(0);
//             robot.backRight.setPower(0);
// 
//             // Turn off RUN_TO_POSITION
//             robot.frontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.frontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.backLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//             robot.backRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
// 
//             //  sleep(250);   // optional pause after each move
//         }
//     }
//     
//     
//     public void shoot() {
//         robot.outtakeR.setPower(-1.0);
//         robot.outtakeL.setPower(-1.0);
//         sleep(500);
//         robot.outtakeR.setPower(1);
//         robot.outtakeL.setPower(1);
//         sleep(1000);
//         robot.intake.setPower(0.4);
//         robot.elevator.setPower(1.0);
//         sleep(300);
//         robot.elevator.setPower(0.8);
//         sleep(800);
//         robot.intake.setPower(0);
//         robot.scoop.setPosition(0.6);
//         sleep(1000);
//         robot.scoop.setPosition(0);
//         sleep(100);
//         robot.intake.setPower(0.4);
//         sleep(1000);
//         robot.scoop.setPosition(0.6);
//         sleep(500);
//         robot.outtakeR.setPower(0);
//         robot.outtakeL.setPower(0);
//         robot.intake.setPower(0);
//         robot.elevator.setPower(0);
//         robot.scoop.setPosition(0);
//     }
//     
//     public void intake(boolean b) {
//         if (b){
//             robot.intake.setPower(0.65);
//             robot.elevator.setPower(1.0);
//             robot.outtakeR.setPower(-0.3);
//             robot.outtakeL.setPower(-0.3);
//         } else {
//             robot.intake.setPower(0);
//             robot.elevator.setPower(0);
//             robot.outtakeR.setPower(0);
//             robot.outtakeL.setPower(0);
//         }
//     }
// }
// 