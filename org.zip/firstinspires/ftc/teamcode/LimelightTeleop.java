// /*
// Copyright 2026 FIRST Tech Challenge Team 9657
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
// associated documentation files (the "Software"), to deal in the Software without restriction,
// including without limitation the rights to use, copy, modify, merge, publish, distribute,
// sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial
// portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
// */
// package org.firstinspires.ftc.teamcode;
// 
// import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
// import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
// import com.qualcomm.robotcore.eventloop.opmode.Disabled;
// import com.qualcomm.robotcore.hardware.DcMotor;
// import com.qualcomm.robotcore.hardware.DcMotorSimple;
// import com.qualcomm.robotcore.util.ElapsedTime;
// import com.qualcomm.hardware.limelightvision.LLResult;
// import com.qualcomm.hardware.limelightvision.LLResultTypes;
// import com.qualcomm.hardware.limelightvision.LLStatus;
// import com.qualcomm.hardware.limelightvision.Limelight3A;
// import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
// import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
// /**
//  * This file contains a minimal example of a Linear "OpMode". An OpMode is a 'program' that runs
//  * in either the autonomous or the TeleOp period of an FTC match. The names of OpModes appear on
//  * the menu of the FTC Driver Station. When an selection is made from the menu, the corresponding
//  * OpMode class is instantiated on the Robot Controller and executed.
//  *
//  * Remove the @Disabled annotation on the next line or two (if present) to add this OpMode to the
//  * Driver Station OpMode list, or add a @Disabled annotation to prevent this OpMode from being
//  * added to the Driver Station.
//  */
// @TeleOp
// 
// public class LimelightTeleop extends LinearOpMode {
// private Limelight3A limelight;
// private double targetAlignThreshold = 10.0;
// 
//     @Override
//     public void runOpMode() {
//         limelight = hardwareMap.get(Limelight3A.class, "limelight");
//         limelight.pipelineSwitch(0);
// 
//         telemetry.addData("Status", "Initialized");
//         telemetry.update();
//         // Wait for the game to start (driver presses PLAY)
//         waitForStart();
//         limelight.start();
// 
//         // run until the end of the match (driver presses STOP)
//         while (opModeIsActive()) {
//         telemetry.addData("Status", "Running");
//         telemetry.update();
//         LLResult result = limelight.getLatestResult();
//         result.getPipelineIndex();
//         if (result != null && result.isValid()) {
//             double tx = result.getTx(); // How far left or right the target is (degrees)
//             double ty = result.getTy(); // How far up or down the target is (degrees)
//             telemetry.addData("Target X", tx);
//             telemetry.addData("Target Y", ty);
//             telemetry.update();
//             
//             if (gamepad2.y) { 
//                 alignWithTarget();
//             
//         } 
// 
//         }
//         
//         private void alignWithTarget() { 
//             if (tx > targetAlignThreshold) {
//                 
//                 
//     }
// }
// 